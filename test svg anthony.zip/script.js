// evenement au demarage
window.onload = delay();
// window.onload = getPos();

// text façon ecriture
var i = 0;
var txt = 'From TROYES to DETROIT'; /* The text */
var speed = 120; /* The speed/duration of the effect in milliseconds */

function typeWriter() {
    if (i < txt.length) {
        document.getElementById("demo").innerHTML += txt.charAt(i);
        i++;
        setTimeout(typeWriter, speed);
    }
}

function delay() {
    setTimeout(typeWriter, 1000)
}

// cache le texte ecrit
let btnStart = document.getElementsByClassName('btnStart')[0];

btnStart.addEventListener('click', delayTexte);

function texteOFF() {
    let texte = document.getElementsByClassName('texte')[0];
    texte.style.display = "none";
}

function delayTexte() {
    setTimeout(texteOFF, 1000)
}


// rotation vinyl
btnStart.addEventListener('click', () => {

    let discVinyl1 = document.getElementsByClassName('vinyl')[0];
    let discVinyl2 = document.getElementsByClassName('vinyl')[1];

    discVinyl1.classList.replace("vinyl", "vinylRotate");
    discVinyl2.classList.replace("vinyl", "vinylRotate");


})


// active header avec delay rotation vinyl
btnStart.addEventListener('click', delayHeader);
let welcom = document.getElementsByClassName('welcomOn')[0];
function headerMain() {

   
    let nav = document.getElementsByClassName('navOff')[0];
    let texte = document.getElementsByClassName('texte')[0];
    let avatar = document.getElementsByClassName('avatarOff')[0];
    let vinylRotate1 = document.getElementsByClassName('vinylRotate')[0];
    let vinylRotate2 = document.getElementsByClassName('vinylRotate')[1];
    let footerOn = document.getElementsByClassName('footer')[0];
    // let welcom = document.getElementsByClassName('welcomOn')[0];
    let card = document.getElementsByClassName('cardOff')[0];
    

   
    nav.setAttribute('class', 'navOn');
    texte.setAttribute('class', 'texteOff');
    avatar.setAttribute('class', 'avatarOn');
    footerOn.setAttribute('class', 'footerOn');
    // welcom.className ='welcom';
    welcom.setAttribute('class', 'welcom');
    card.setAttribute('class', 'cardOn');

}



function delayHeader() {
    setTimeout(headerMain, 2000);
}


// déplace le titre
btnStart.addEventListener('click', delaydeplaceTitre);

function deplaceTitre() {
    
 let titre = document.getElementsByClassName('titre')[0];
 titre.setAttribute('class', 'titre-header');
}
function delaydeplaceTitre() {
    setTimeout(deplaceTitre, 1000);
}







//active who I am section
let whoI = document.querySelector('.whoI');
let disco = document.querySelector('.disco');

let biography = document.querySelector('.biography');
// const welcomOn = document.querySelector('.welcom');
let discographys = document.querySelector('.discographys');


whoI.addEventListener('click', () => {
    biography.classList.toggle("biographyOn");
    discographys.classList.replace("discographysOn", "discographys");
    
    if (biography.classList == "biography biographyOn"){
        welcom.classList.replace("welcom", "welcomOn");
    }else{
        welcom.classList.replace("welcomOn", "welcom");
    }

});



disco.addEventListener('click', () => {
    discographys.classList.toggle("discographysOn");
    biography.classList.replace("biographyOn", "biography");
    
    if (discographys.classList == "discographys discographysOn"){
        welcom.classList.replace("welcom", "welcomOn");
    }else{
        welcom.classList.replace("welcomOn", "welcom");
    }

});











